module.exports = {
  extends: 'unu',
  rules: {
    'no-console': 'off'
  }
}
