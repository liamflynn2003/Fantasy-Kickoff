package org.fgn.schema.data;

public class SchemaException extends RuntimeException {

    public SchemaException(String msg) {
        super(msg);
    }
}
