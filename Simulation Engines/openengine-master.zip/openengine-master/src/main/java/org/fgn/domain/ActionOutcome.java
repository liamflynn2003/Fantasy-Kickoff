package org.fgn.domain;

public enum ActionOutcome {
    GS, // Goalkeeper save
    PST // Post
}
