package org.fgn.domain;

public enum Action {
    PASS, LONGPASS, BOUNCEOFF
}
