package org.fgn.domain;

public enum PlayingCondition {
    HD, // Header
    FT, // First-touch
    GH // Goalkeeper-hold
}
