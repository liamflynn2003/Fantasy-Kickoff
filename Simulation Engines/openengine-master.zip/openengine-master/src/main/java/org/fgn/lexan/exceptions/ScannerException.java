package org.fgn.lexan.exceptions;

public class ScannerException extends Exception {

    public ScannerException(String msg) {
        super(msg);
    }
}
