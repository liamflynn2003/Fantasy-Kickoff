package org.fgn.domain;

import java.util.ArrayList;
import java.util.List;

public class Match {

    private String homeTeam;
    private String awayTeam;

    private int halfTimeIndex;
    private List<EventSequence> sequences = new ArrayList<>();

    public void add(EventSequence sequence) {
        this.sequences.add(sequence);
    }
}
