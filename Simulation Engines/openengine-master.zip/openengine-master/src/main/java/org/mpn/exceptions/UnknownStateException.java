package org.mpn.exceptions;

public class UnknownStateException extends Exception {
}
