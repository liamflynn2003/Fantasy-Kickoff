package org.mpn;

public enum Directive implements ProcessUnit {
    BREAK, HT
}
