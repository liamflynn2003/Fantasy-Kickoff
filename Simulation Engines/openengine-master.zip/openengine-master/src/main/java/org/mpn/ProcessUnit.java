package org.mpn;

public interface ProcessUnit {
}
