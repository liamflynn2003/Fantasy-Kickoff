package org.openengine.mv;
public class Player {

    private PlayerAttributes attributes;
}
