package org.openengine.pureengine.config;

public class Debug {
    public static final boolean DISPLAY_MATCH_xG = false;
}
