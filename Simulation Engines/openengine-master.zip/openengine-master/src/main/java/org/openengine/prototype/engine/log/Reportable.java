package org.openengine.prototype.engine.log;

public interface Reportable {

    String getMessage();
}