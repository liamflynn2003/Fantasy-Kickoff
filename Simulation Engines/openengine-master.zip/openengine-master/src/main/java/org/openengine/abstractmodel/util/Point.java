package org.openengine.abstractmodel.util;

public record Point(int x, int y) {
}
