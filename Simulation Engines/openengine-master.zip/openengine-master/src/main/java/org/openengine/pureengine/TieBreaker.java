package org.openengine.pureengine;

public enum TieBreaker {
    NONE, RANDOM, EXTRA_TIME, EXTRA_TIME_PENALTIES, PENALTIES
}
