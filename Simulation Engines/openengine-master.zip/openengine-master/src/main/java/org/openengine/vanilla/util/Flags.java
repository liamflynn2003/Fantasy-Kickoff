package org.openengine.vanilla.util;

public class Flags {
    public static boolean LOGGING = false;
}
