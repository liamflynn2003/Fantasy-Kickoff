package org.openengine.pureengine.domain.repository;

import java.util.Collection;

public interface Repository {

}
