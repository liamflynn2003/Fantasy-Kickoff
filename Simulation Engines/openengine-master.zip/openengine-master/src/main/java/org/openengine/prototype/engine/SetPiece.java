package org.openengine.prototype.engine;

public enum SetPiece {
    H, F, O
}
