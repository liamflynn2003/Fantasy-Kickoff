package org.openengine.pureengine;

public enum MatchEventType {
    GOAL;
}
