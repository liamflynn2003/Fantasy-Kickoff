package org.openengine.abstractmodel;

import java.util.ArrayList;
import java.util.List;

public class TacticalRegionHeatmap {
    private List<TacticalRegionHeatmapPresence> playersPresence = new ArrayList<>();
}
