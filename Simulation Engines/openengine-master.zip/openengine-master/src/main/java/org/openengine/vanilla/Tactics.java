package org.openengine.vanilla;

public enum Tactics {
    _4_4_2,
    _4_3_3
}
