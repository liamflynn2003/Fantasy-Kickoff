package org.openengine.prototype.engine;

public enum Coordinates {
    GK, Dg, Dp, D, D_T, D_SP, A_T, C, Aw, A, Ap, ApFTA
}
