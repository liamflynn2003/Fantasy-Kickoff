package org.openengine.prototype.engine;

public class TeamStats {

    private int score;

    public int getScore() {
        return this.score;
    }

    public void incrementScore() {
        this.score++;
    }
}
