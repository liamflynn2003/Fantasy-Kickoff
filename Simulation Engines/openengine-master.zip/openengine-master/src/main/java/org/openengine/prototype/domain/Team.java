package org.openengine.prototype.domain;

public interface Team {

    String getName();
    Squad getSquad();

}
