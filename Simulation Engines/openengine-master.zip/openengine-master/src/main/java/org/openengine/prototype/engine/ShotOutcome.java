package org.openengine.prototype.engine;

enum ShotOutcome {
    CATCH, BLOCK, GOAL_KICK, GOAL_KICK_HIGH, SAVE, POST, GOAL
}
