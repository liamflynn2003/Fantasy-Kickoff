package org.openengine.prototype.engine;

public interface OutcomeWeight {
    int getWeight();
    Outcome getOutcome();
}
