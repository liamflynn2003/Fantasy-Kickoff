package org.openengine.vanilla;

public enum ActionType {
    Shoot, Pass
}
