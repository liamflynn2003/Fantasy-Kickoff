package org.openengine.prototype.domain.exceptions;

public class InvalidFlagException extends Exception {
}
