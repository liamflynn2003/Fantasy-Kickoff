package org.openengine.prototype.util.fgn;

public class Token {

    private String value;

    public Token(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
