package org.openengine.openfootie;

public record MatchSequence (MatchPhaseTransition[] matchPhaseTransitions) { }
