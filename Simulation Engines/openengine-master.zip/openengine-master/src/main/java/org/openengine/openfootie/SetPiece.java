package org.openengine.openfootie;

public enum SetPiece implements MatchDataElementType {
    KICK_OFF,
    PENALTY,
    THROW_IN,
    CORNER_KICK,
    FREE_KICK,
    INDIRECT_FREE_KICK,
    GOAL_KICK
}
