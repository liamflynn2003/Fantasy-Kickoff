package org.openengine.mv;

public class PlayerAttributes {

    private int shooting;
}
