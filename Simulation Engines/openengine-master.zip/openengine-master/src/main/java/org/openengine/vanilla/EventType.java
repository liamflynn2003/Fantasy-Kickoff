package org.openengine.vanilla;

public enum EventType {
    GOAL_SCORED, SHOT, ATTACKING_TOUCH
}
