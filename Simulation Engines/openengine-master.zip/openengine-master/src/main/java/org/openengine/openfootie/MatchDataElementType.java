package org.openengine.openfootie;

public interface MatchDataElementType {
}
