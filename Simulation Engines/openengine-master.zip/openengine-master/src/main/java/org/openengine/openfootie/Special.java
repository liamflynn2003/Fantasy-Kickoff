package org.openengine.openfootie;

public enum Special implements MatchDataElementType {
    MAIN
}
