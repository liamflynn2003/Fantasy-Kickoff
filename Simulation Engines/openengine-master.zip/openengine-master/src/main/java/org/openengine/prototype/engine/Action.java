package org.openengine.prototype.engine;

public enum Action {
    Default, Hold, Long, LowCross, ForwardPass, Cross, BackPass, Move, Shoot, Dribble, LateralPass, CrossPass
}
