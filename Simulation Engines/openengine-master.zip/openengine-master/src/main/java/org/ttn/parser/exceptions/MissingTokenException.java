package org.ttn.parser.exceptions;

public class MissingTokenException extends ParserException {
    public MissingTokenException(String msg) {
        super(msg);
    }
}
