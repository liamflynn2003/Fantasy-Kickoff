package org.ttn.lexan;

public class Token {
}
