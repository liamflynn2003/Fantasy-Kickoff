package org.ttn.semantics.exceptions;

public class InvalidPhaseException extends Exception {

    public InvalidPhaseException(String message) {
        super(message);
    }
}
