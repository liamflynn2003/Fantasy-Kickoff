package org.ttn.engine.space;

public enum PitchPosition {
    Gkr, Gkd,
    Dg, Dp, Dpd, Dpw, Dwp, Dw, D, Dd, DM, DMd, DMw,
    MD, MDw, MDd, Mw, Md, M, AM,
    AMd, AMw, Aw, Awp, A, Apd, Apw, Ap, Ad,
    KO, CK, GK
}
