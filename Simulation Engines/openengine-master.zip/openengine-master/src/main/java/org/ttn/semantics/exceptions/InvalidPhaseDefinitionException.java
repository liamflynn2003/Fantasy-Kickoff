package org.ttn.semantics.exceptions;

public class InvalidPhaseDefinitionException extends Exception {

    public InvalidPhaseDefinitionException(String msg) {
        super(msg);
    }
}
