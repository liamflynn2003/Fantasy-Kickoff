package org.ttn.engine.rules;

public enum SetPiece {
    KICK_OFF, PENALTY, THROW_IN, CORNER_KICK, FREEKICK
}
