package org.ttn.lexan.exceptions;

public class ScannerException extends Exception {

    public ScannerException(String msg) {
        super(msg);
    }
}
