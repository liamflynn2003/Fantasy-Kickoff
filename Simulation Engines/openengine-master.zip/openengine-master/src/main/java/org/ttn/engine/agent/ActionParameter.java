package org.ttn.engine.agent;

public enum ActionParameter {
    OPEN_PASS, FIRST_TOUCH
}
