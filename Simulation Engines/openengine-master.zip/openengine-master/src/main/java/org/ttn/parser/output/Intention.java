package org.ttn.parser.output;

public enum Intention {
    BREAK_BALL, ATTACK, COOL_DOWN, WITHDRAW_PRESSURE, RELEASE_PRESSING
}
