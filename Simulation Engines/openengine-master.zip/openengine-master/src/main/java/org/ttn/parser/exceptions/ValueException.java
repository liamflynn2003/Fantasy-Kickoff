package org.ttn.parser.exceptions;

public class ValueException extends ParserException {

    public ValueException(String msg) {
        super(msg);
    }
}
